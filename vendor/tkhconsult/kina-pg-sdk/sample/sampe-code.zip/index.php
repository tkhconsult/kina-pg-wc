<?php

include('vendor/autoload.php');

use Symfony\Component\Dotenv\Dotenv;
use TkhConsult\KinaBankGateway\KinaBankGateway;

$dotenv = new Dotenv(1);
$dotenv->load(__DIR__.'/.env');

$kinaBankGateway = new KinaBankGateway();
$certDir = './key/';
$kinaBankGateway
    ->configureFromEnv($certDir)
    ->setGatewayUrl('https://devegateway.kinabank.com.pg/cgi-bin/cgi_link')  // for testing
;

$backRefUrl = getenv('KINA_BANK_MERCHANT_URL').'/after-payment.php';

/** @var KinaBankGateway $kinaBankGateway */
$kinaBankGateway
    ->requestAuthorization($orderId = 1, $amount = 1, $backRefUrl, $currency = "PGK", $description = "iPhone X Pro", $clientEmail = "customer@yopmail.com", $language = 'en')
;
